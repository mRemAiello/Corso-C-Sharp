/*

https://www.w3resource.com/csharp-exercises/exception-handling/index.php

*/