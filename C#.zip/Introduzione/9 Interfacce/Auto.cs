/*public class Auto : Veicolo2
{
    private int _numeroPorte;
    
    public Auto(string marca, string modello, int numeroPorte) : base(marca, modello)
    {
        _numeroPorte = numeroPorte;
    }

    public int GetNumeroPorte()
    {
        return _numeroPorte;
    }

    public void MostraDettagli()
    {
        string str = "{0} {1} con {2} porte.";
        Console.WriteLine(string.Format(str, GetModello(), GetMarca(), GetNumeroPorte()));
    }
}*/