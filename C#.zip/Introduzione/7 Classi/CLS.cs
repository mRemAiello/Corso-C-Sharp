

public class CLS
{
    public void Execute()
    {
        Automobile auto = new Automobile();
        auto.MostraInformazioni();
    }
}