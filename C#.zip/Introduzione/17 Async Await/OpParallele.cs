public class OpParallele
{
    static async Task Main(string[] args)
    {
        // Avvio di più operazioni asincrone in parallelo
        Task operazione1 = OperazioneAsincrona("Operazione 1", 2000);
        Task operazione2 = OperazioneAsincrona("Operazione 2", 3000);
        Task operazione3 = OperazioneAsincrona("Operazione 3", 1000);

        // Attende il completamento di tutte le operazioni
        await Task.WhenAll(operazione1, operazione2, operazione3);

        Console.WriteLine("Tutte le operazioni sono completate.");
    }

    // Metodo asincrono che simula un'operazione con un'attesa variabile
    static async Task OperazioneAsincrona(string nomeOperazione, int delay)
    {
        Console.WriteLine($"{nomeOperazione} avviata.");
        await Task.Delay(delay);
        Console.WriteLine($"{nomeOperazione} completata.");
    }
}