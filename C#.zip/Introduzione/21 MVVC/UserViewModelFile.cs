
public class UserViewModelFile : IUserViewModel
{
    public void AddUser(string name, int age)
    {
        throw new NotImplementedException();
    }

    public void ClearUsers()
    {
        throw new NotImplementedException();
    }

    public IEnumerable<User> GetUsers()
    {
        throw new NotImplementedException();
    }

    public void RemoveUser(string name)
    {
        throw new NotImplementedException();
    }
}