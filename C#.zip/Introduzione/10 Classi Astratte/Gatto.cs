public class Gatto : Animale
{
    public override void Funzione()
    {
    }

    public override void Verso()
    {
        Console.WriteLine("Il gatto miagola.");
    }
}