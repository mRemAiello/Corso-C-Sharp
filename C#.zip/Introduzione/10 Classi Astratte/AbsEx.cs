/*

https://www.studytrigger.com/article/practice-problems-on-abstract-class-in-java/


https://www.tutorjoes.in/java_programming_tutorial/abstract_class_exercise_programs_in_java


https://www.w3resource.com/java-exercises/java-abstract-class-exercise-8.php

*/