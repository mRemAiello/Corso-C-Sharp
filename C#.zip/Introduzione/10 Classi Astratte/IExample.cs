public interface IExample
{
    void Funzione();
}