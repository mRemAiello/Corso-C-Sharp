public class Gatto : Animale
{
    public override void Verso()
    {
        Console.WriteLine("Il gatto miagola.");
    }
}