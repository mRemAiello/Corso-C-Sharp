public abstract class Animale
{
    public abstract void Verso();
    
    public void Dormi()
    {
        Console.WriteLine("L'animale dorme.");
    }
}