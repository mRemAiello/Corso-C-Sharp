public interface IVeicolo
{
    void Avvia();
    void Arresta();
}